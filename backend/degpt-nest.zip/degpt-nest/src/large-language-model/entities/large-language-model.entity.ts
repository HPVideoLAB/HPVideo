export class LargeLanguageModel {}
